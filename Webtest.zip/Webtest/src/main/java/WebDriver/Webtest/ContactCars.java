package WebDriver.Webtest;

import java.io.File;
import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class ContactCars {

	public static void main(String[] args) throws Exception, IOException {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\v18nsayed33\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");

		WebDriver webdriver = new ChromeDriver();

		String baseURL = "https://www.contactcars.com";
		JavascriptExecutor js = (JavascriptExecutor) webdriver;

		webdriver.get(baseURL);
		webdriver.manage().window().maximize();
		Thread.sleep(5000);
		Select car_brand = new Select (webdriver.findElement(By.id("ncmakes")));
		car_brand.selectByVisibleText("كيا");
		
		Select car_model = new Select (webdriver.findElement(By.id("ncmodels")));
		car_model.selectByVisibleText("ريو");	
		
		WebElement search_btn = webdriver.findElement(By.id("btnnewsearch"));
		search_btn.click();
		
		Thread.sleep(5000);
		WebElement car_details = webdriver.findElement(By.linkText("1.6 A/T H/L New Shape Sedan"));
		js.executeScript("arguments[0].scrollIntoView();", car_details);
		car_details.click();
		
		Thread.sleep(5000);
		WebElement installment = webdriver.findElement(By.linkText("قسّط"));
		js.executeScript("arguments[0].scrollIntoView();", installment);
		installment.click();
		
		Thread.sleep(5000);
		WebElement installment_approve = webdriver.findElement(By.id("buy"));
		js.executeScript("arguments[0].scrollIntoView();", installment_approve);
		WebElement installment_amount = webdriver.findElement(By.id("monthly_installments_inst"));
		String amount = installment_amount.getText();
		System.out.println(amount);


	}
}
